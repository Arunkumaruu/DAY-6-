document.getElementById('changeTextButton').addEventListener('click', function() {
    const textElement = document.getElementById('text');
    const aspnetIntro = document.getElementById('aspnetIntro');
    const aspnetFeatures = document.getElementById('aspnetFeatures');

    // Fade out animation for main text
    anime({
        targets: textElement,
        opacity: 0,
        duration: 500,
        easing: 'easeInOutQuad',
        complete: function() {
            textElement.textContent = '.NET FRAMEWORK';
            
            // Fade in animation for main text
            anime({
                targets: textElement,
                opacity: 1,
                duration: 500,
                easing: 'easeInOutQuad'
            });
        }
    });

    // Fade in animation for ASP.NET content
    anime({
        targets: [aspnetIntro, aspnetFeatures],
        opacity: [0, 1],
        duration: 500,
        easing: 'easeInOutQuad',
        delay: anime.stagger(250) // stagger the animation by 250ms for each element
    });
});
